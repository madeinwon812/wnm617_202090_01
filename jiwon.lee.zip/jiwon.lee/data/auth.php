<?php

function Auth() {
	$host = "localhost";
	$user = "madeinwon";
	$pass = "tosvmfks!";
	$dbname = "jiwon_wnm617";
    return [
      "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
      $user,
      $pass
   ];
}

